package net.ldm.mo_enchants.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.BlockPos;

import net.ldm.mo_enchants.init.MoEnchantsModEnchantments;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class AquaphobiaCurseHelperProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Entity entity = event.player;
			execute(event, entity.level, entity.getX(), entity.getY(), entity.getZ(), entity);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (((world.getBlockState(new BlockPos((int) x, (int) y, (int) z))).getBlock()instanceof LiquidBlock _liquid
				? new ItemStack(_liquid.getFluid().getBucket())
				: ItemStack.EMPTY).getItem() == Items.WATER_BUCKET
				&& (EnchantmentHelper.getItemEnchantmentLevel(MoEnchantsModEnchantments.AQUAPHOBIA_CURSE,
						(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY)) != 0
						|| EnchantmentHelper.getItemEnchantmentLevel(MoEnchantsModEnchantments.AQUAPHOBIA_CURSE,
								(entity instanceof LivingEntity _entGetArmor
										? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST)
										: ItemStack.EMPTY)) != 0
						|| EnchantmentHelper.getItemEnchantmentLevel(MoEnchantsModEnchantments.AQUAPHOBIA_CURSE,
								(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)) != 0
						|| EnchantmentHelper.getItemEnchantmentLevel(MoEnchantsModEnchantments.AQUAPHOBIA_CURSE,
								(entity instanceof LivingEntity _entGetArmor
										? _entGetArmor.getItemBySlot(EquipmentSlot.FEET)
										: ItemStack.EMPTY)) != 0)) {
			if (!entity.getPersistentData().getBoolean("aquaphobiaDamageCooldown")) {
				if (entity instanceof LivingEntity _entity)
					_entity.hurt(new DamageSource("curse.aquaphobia").bypassArmor(), 1);
				entity.getPersistentData().putBoolean("aquaphobiaDamageCooldown", (true));
			} else {
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private LevelAccessor world;

					public void start(LevelAccessor world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						entity.getPersistentData().putBoolean("aquaphobiaDamageCooldown", (false));
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, 10);
			}
		}
	}
}
