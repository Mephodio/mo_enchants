
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ldm.mo_enchants.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.enchantment.Enchantment;

import net.ldm.mo_enchants.enchantment.UltimateFinishEnchantment;
import net.ldm.mo_enchants.enchantment.ToxicAspectEnchantment;
import net.ldm.mo_enchants.enchantment.SoulSparkEnchantment;
import net.ldm.mo_enchants.enchantment.SmeltingTouchEnchantment;
import net.ldm.mo_enchants.enchantment.SavingGraceEnchantment;
import net.ldm.mo_enchants.enchantment.RockMendingEnchantment;
import net.ldm.mo_enchants.enchantment.RevenantEnchantment;
import net.ldm.mo_enchants.enchantment.ReachEnchantment;
import net.ldm.mo_enchants.enchantment.PanicEnchantment;
import net.ldm.mo_enchants.enchantment.NightVisionEnchantment;
import net.ldm.mo_enchants.enchantment.MagmaWalkerEnchantment;
import net.ldm.mo_enchants.enchantment.LifeforceDischargeCurseEnchantment;
import net.ldm.mo_enchants.enchantment.LifeStealEnchantment;
import net.ldm.mo_enchants.enchantment.LevitatingEnchantment;
import net.ldm.mo_enchants.enchantment.LeapingEnchantment;
import net.ldm.mo_enchants.enchantment.HunterEnchantment;
import net.ldm.mo_enchants.enchantment.FrostEnchantment;
import net.ldm.mo_enchants.enchantment.FreezingCurseEnchantment;
import net.ldm.mo_enchants.enchantment.FreezingAspectEnchantment;
import net.ldm.mo_enchants.enchantment.FireCoatingEnchantment;
import net.ldm.mo_enchants.enchantment.EvokersFangEnchantment;
import net.ldm.mo_enchants.enchantment.DetonationEnchantment;
import net.ldm.mo_enchants.enchantment.DensityCurseEnchantment;
import net.ldm.mo_enchants.enchantment.CurseOfScorchingEnchantment;
import net.ldm.mo_enchants.enchantment.CurseOfHarmingEnchantment;
import net.ldm.mo_enchants.enchantment.ConductionEnchantment;
import net.ldm.mo_enchants.enchantment.BoilingCurseEnchantment;
import net.ldm.mo_enchants.enchantment.BloodthirstEnchantment;
import net.ldm.mo_enchants.enchantment.BadDreamsCurseEnchantment;
import net.ldm.mo_enchants.enchantment.AquaphobiaCurseEnchantment;
import net.ldm.mo_enchants.enchantment.AquaSlashEnchantment;
import net.ldm.mo_enchants.enchantment.AngelsBlessingEnchantment;
import net.ldm.mo_enchants.enchantment.AccelerationEnchantment;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoEnchantsModEnchantments {
	private static final List<Enchantment> REGISTRY = new ArrayList<>();
	public static final Enchantment HARMING_CURSE = register("mo_enchants:harming_curse", new CurseOfHarmingEnchantment());
	public static final Enchantment ULTIMATE_FINISH = register("mo_enchants:ultimate_finish", new UltimateFinishEnchantment());
	public static final Enchantment SCORCHING_CURSE = register("mo_enchants:scorching_curse", new CurseOfScorchingEnchantment());
	public static final Enchantment VENOMFANG = register("mo_enchants:venomfang", new ToxicAspectEnchantment());
	public static final Enchantment SMELTING_TOUCH = register("mo_enchants:smelting_touch", new SmeltingTouchEnchantment());
	public static final Enchantment LIFE_STEAL = register("mo_enchants:life_steal", new LifeStealEnchantment());
	public static final Enchantment FREEZING_ASPECT = register("mo_enchants:freezing_aspect", new FreezingAspectEnchantment());
	public static final Enchantment LIFEFORCE_DISCHARGE_CURSE = register("mo_enchants:lifeforce_discharge_curse",
			new LifeforceDischargeCurseEnchantment());
	public static final Enchantment PANIC = register("mo_enchants:panic", new PanicEnchantment());
	public static final Enchantment CONDUCTION = register("mo_enchants:conduction", new ConductionEnchantment());
	public static final Enchantment SAVING_GRACE = register("mo_enchants:saving_grace", new SavingGraceEnchantment());
	public static final Enchantment FROST = register("mo_enchants:frost", new FrostEnchantment());
	public static final Enchantment AQUA_SLASH = register("mo_enchants:aqua_slash", new AquaSlashEnchantment());
	public static final Enchantment HUNTER = register("mo_enchants:hunter", new HunterEnchantment());
	public static final Enchantment SWIFTNESS = register("mo_enchants:swiftness", new AccelerationEnchantment());
	public static final Enchantment SOUL_SPARK = register("mo_enchants:soul_spark", new SoulSparkEnchantment());
	public static final Enchantment BOILING_CURSE = register("mo_enchants:boiling_curse", new BoilingCurseEnchantment());
	public static final Enchantment FREEZING_CURSE = register("mo_enchants:freezing_curse", new FreezingCurseEnchantment());
	public static final Enchantment BAD_DREAMS_CURSE = register("mo_enchants:bad_dreams_curse", new BadDreamsCurseEnchantment());
	public static final Enchantment ANGELS_BLESSING = register("mo_enchants:angels_blessing", new AngelsBlessingEnchantment());
	public static final Enchantment ROCK_MENDING = register("mo_enchants:rock_mending", new RockMendingEnchantment());
	public static final Enchantment LEVITATING = register("mo_enchants:levitating", new LevitatingEnchantment());
	public static final Enchantment DETONATION = register("mo_enchants:detonation", new DetonationEnchantment());
	public static final Enchantment NIGHT_VISION = register("mo_enchants:night_vision", new NightVisionEnchantment());
	public static final Enchantment AQUAPHOBIA_CURSE = register("mo_enchants:aquaphobia_curse", new AquaphobiaCurseEnchantment());
	public static final Enchantment LEAPING = register("mo_enchants:leaping", new LeapingEnchantment());
	public static final Enchantment DENSITY_CURSE = register("mo_enchants:density_curse", new DensityCurseEnchantment());
	public static final Enchantment REACH = register("mo_enchants:reach", new ReachEnchantment());
	public static final Enchantment BLOODTHIRST = register("mo_enchants:bloodthirst", new BloodthirstEnchantment());
	public static final Enchantment EVOKERS_FANG = register("mo_enchants:evokers_fang", new EvokersFangEnchantment());
	public static final Enchantment REVENANT = register("mo_enchants:revenant", new RevenantEnchantment());
	public static final Enchantment MAGMA_WALKER = register("mo_enchants:magma_walker", new MagmaWalkerEnchantment());
	public static final Enchantment FIRE_COATING = register("mo_enchants:fire_coating", new FireCoatingEnchantment());

	private static Enchantment register(String registryname, Enchantment enchantment) {
		REGISTRY.add(enchantment.setRegistryName(registryname));
		return enchantment;
	}

	@SubscribeEvent
	public static void registerEnchantments(RegistryEvent.Register<Enchantment> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Enchantment[0]));
	}
}
