package net.ldm.mo_enchants.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;

import net.ldm.mo_enchants.MoEnchantsMod;

import java.util.Map;

public class TotemlikeAnimationMainhandProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency entity for procedure TotemlikeAnimationMainhand!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency world for procedure TotemlikeAnimationMainhand!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		IWorld world = (IWorld) dependencies.get("world");
		if (world.isRemote()) {
			Minecraft.getInstance().gameRenderer
					.displayItemActivation(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
		}
	}
}
