package net.ldm.mo_enchants.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantment;

import net.ldm.mo_enchants.enchantment.AngelsBlessingEnchantment;
import net.ldm.mo_enchants.MoEnchantsMod;

import java.util.Map;
import java.util.HashMap;

public class AngelsBlessingHelperProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onEntityAttacked(LivingHurtEvent event) {
			if (event != null && event.getEntity() != null) {
				Entity entity = event.getEntity();
				Entity sourceentity = event.getSource().getTrueSource();
				double i = entity.getPosX();
				double j = entity.getPosY();
				double k = entity.getPosZ();
				double amount = event.getAmount();
				World world = entity.world;
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("amount", amount);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("sourceentity", sourceentity);
				dependencies.put("event", event);
				executeProcedure(dependencies);
			}
		}
	}
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency entity for procedure AngelsBlessingHelper!");
			return;
		}
		if (dependencies.get("amount") == null) {
			if (!dependencies.containsKey("amount"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency amount for procedure AngelsBlessingHelper!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency x for procedure AngelsBlessingHelper!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency y for procedure AngelsBlessingHelper!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency z for procedure AngelsBlessingHelper!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MoEnchantsMod.LOGGER.warn("Failed to load dependency world for procedure AngelsBlessingHelper!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double amount = dependencies.get("amount") instanceof Integer ? (int) dependencies.get("amount") : (double) dependencies.get("amount");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double oldEnchLv = 0;
		if (((amount) > ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1))) {
			if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
					.getItem() == Items.TOTEM_OF_UNDYING)
					&& ((EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
							((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)) != 0)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) 1);
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).clearActivePotions();
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.REGENERATION, (int) 900, (int) 1));
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.ABSORPTION, (int) 100, (int) 1));
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, (int) 800, (int) 0));
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					$_dependencies.put("world", world);
					TotemlikeAnimationMainhandProcedure.executeProcedure($_dependencies);
				}
				if (world instanceof World && !world.isRemote()) {
					((World) world).playSound(null, new BlockPos((int) x, (int) y, (int) z),
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.totem.use")),
							SoundCategory.NEUTRAL, (float) 1, (float) 1);
				} else {
					((World) world).playSound(x, y, z,
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.totem.use")),
							SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
				}
				if (((EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
						((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY))) == 1)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(
								((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
						if (_enchantments.containsKey(AngelsBlessingEnchantment.enchantment)) {
							_enchantments.remove(AngelsBlessingEnchantment.enchantment);
							EnchantmentHelper.setEnchantments(_enchantments,
									((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
						}
					}
				} else {
					oldEnchLv = (double) (EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
							((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)));
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(
								((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
						if (_enchantments.containsKey(AngelsBlessingEnchantment.enchantment)) {
							_enchantments.remove(AngelsBlessingEnchantment.enchantment);
							EnchantmentHelper.setEnchantments(_enchantments,
									((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
						}
					}
					(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY))
							.addEnchantment(AngelsBlessingEnchantment.enchantment, (int) (oldEnchLv - 1));
				}
			} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)
					.getItem() == Items.TOTEM_OF_UNDYING)
					&& ((EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
							((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)) != 0)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) 1);
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).clearActivePotions();
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.REGENERATION, (int) 900, (int) 1));
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, (int) 800, (int) 0));
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.ABSORPTION, (int) 100, (int) 1));
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					$_dependencies.put("world", world);
					TotemlikeAnimationOffhandProcedure.executeProcedure($_dependencies);
				}
				if (world instanceof World && !world.isRemote()) {
					((World) world).playSound(null, new BlockPos((int) x, (int) y, (int) z),
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.totem.use")),
							SoundCategory.NEUTRAL, (float) 1, (float) 1);
				} else {
					((World) world).playSound(x, y, z,
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.totem.use")),
							SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
				}
				if (((EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
						((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY))) == 1)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper
								.getEnchantments(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY));
						if (_enchantments.containsKey(AngelsBlessingEnchantment.enchantment)) {
							_enchantments.remove(AngelsBlessingEnchantment.enchantment);
							EnchantmentHelper.setEnchantments(_enchantments,
									((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY));
						}
					}
				} else {
					oldEnchLv = (double) (EnchantmentHelper.getEnchantmentLevel(AngelsBlessingEnchantment.enchantment,
							((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)));
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper
								.getEnchantments(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY));
						if (_enchantments.containsKey(AngelsBlessingEnchantment.enchantment)) {
							_enchantments.remove(AngelsBlessingEnchantment.enchantment);
							EnchantmentHelper.setEnchantments(_enchantments,
									((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY));
						}
					}
					(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY))
							.addEnchantment(AngelsBlessingEnchantment.enchantment, (int) (oldEnchLv - 1));
				}
			}
		}
	}
}
