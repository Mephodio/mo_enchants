package net.ldm.mo_enchants.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import java.util.UUID;

@Mod.EventBusSubscriber
public class GrowthHelperProcedure {
	GROWTH_ENCHANTMENT_HEALTH = new AttributeModifier("0c14b739-c2bd-472b-8da5-3d8bb0d5fc7a", "growthEnchantmentAddedHealth", 0.360D, 0);

	@SubscribeEvent
	public static void onEquipmentChange( LivingEquipmentChangeEvent event, LivingEntity entity, ItemStack to) {
		execute(event, entity, to);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack to) {
		entity.getEntityAttribute(MY_ATTRIBUTE_INSTANCE).applyModifier(GROWTH_ENCHANTMENT_HEALTH);
	}
}
