
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ldm.mo_enchants.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.ldm.mo_enchants.enchantment.UltimateFinishEnchantment;
import net.ldm.mo_enchants.enchantment.ToxicAspectEnchantment;
import net.ldm.mo_enchants.enchantment.SoulSparkEnchantment;
import net.ldm.mo_enchants.enchantment.SmeltingTouchEnchantment;
import net.ldm.mo_enchants.enchantment.SavingGraceEnchantment;
import net.ldm.mo_enchants.enchantment.RockMendingEnchantment;
import net.ldm.mo_enchants.enchantment.RevenantEnchantment;
import net.ldm.mo_enchants.enchantment.ReachEnchantment;
import net.ldm.mo_enchants.enchantment.PanicEnchantment;
import net.ldm.mo_enchants.enchantment.NightVisionEnchantment;
import net.ldm.mo_enchants.enchantment.MagmaWalkerEnchantment;
import net.ldm.mo_enchants.enchantment.LifeforceDischargeCurseEnchantment;
import net.ldm.mo_enchants.enchantment.LifeStealEnchantment;
import net.ldm.mo_enchants.enchantment.LevitatingEnchantment;
import net.ldm.mo_enchants.enchantment.LeapingEnchantment;
import net.ldm.mo_enchants.enchantment.HunterEnchantment;
import net.ldm.mo_enchants.enchantment.GrowthEnchantment;
import net.ldm.mo_enchants.enchantment.FrostEnchantment;
import net.ldm.mo_enchants.enchantment.FreezingCurseEnchantment;
import net.ldm.mo_enchants.enchantment.FreezingAspectEnchantment;
import net.ldm.mo_enchants.enchantment.FireCoatingEnchantment;
import net.ldm.mo_enchants.enchantment.DetonationEnchantment;
import net.ldm.mo_enchants.enchantment.DensityCurseEnchantment;
import net.ldm.mo_enchants.enchantment.CurseOfScorchingEnchantment;
import net.ldm.mo_enchants.enchantment.CurseOfHarmingEnchantment;
import net.ldm.mo_enchants.enchantment.ConductionEnchantment;
import net.ldm.mo_enchants.enchantment.BoilingCurseEnchantment;
import net.ldm.mo_enchants.enchantment.BloodthirstEnchantment;
import net.ldm.mo_enchants.enchantment.BadDreamsCurseEnchantment;
import net.ldm.mo_enchants.enchantment.AquaphobiaCurseEnchantment;
import net.ldm.mo_enchants.enchantment.AquaSlashEnchantment;
import net.ldm.mo_enchants.enchantment.AngelsBlessingEnchantment;
import net.ldm.mo_enchants.enchantment.AccelerationEnchantment;
import net.ldm.mo_enchants.MoEnchantsMod;

public class MoEnchantsModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MoEnchantsMod.MODID);
	public static final RegistryObject<Enchantment> HARMING_CURSE = REGISTRY.register("harming_curse", () -> new CurseOfHarmingEnchantment());
	public static final RegistryObject<Enchantment> ULTIMATE_FINISH = REGISTRY.register("ultimate_finish", () -> new UltimateFinishEnchantment());
	public static final RegistryObject<Enchantment> SCORCHING_CURSE = REGISTRY.register("scorching_curse", () -> new CurseOfScorchingEnchantment());
	public static final RegistryObject<Enchantment> VENOMFANG = REGISTRY.register("venomfang", () -> new ToxicAspectEnchantment());
	public static final RegistryObject<Enchantment> SMELTING_TOUCH = REGISTRY.register("smelting_touch", () -> new SmeltingTouchEnchantment());
	public static final RegistryObject<Enchantment> LIFE_STEAL = REGISTRY.register("life_steal", () -> new LifeStealEnchantment());
	public static final RegistryObject<Enchantment> FREEZING_ASPECT = REGISTRY.register("freezing_aspect", () -> new FreezingAspectEnchantment());
	public static final RegistryObject<Enchantment> LIFEFORCE_DISCHARGE_CURSE = REGISTRY.register("lifeforce_discharge_curse",
			() -> new LifeforceDischargeCurseEnchantment());
	public static final RegistryObject<Enchantment> PANIC = REGISTRY.register("panic", () -> new PanicEnchantment());
	public static final RegistryObject<Enchantment> CONDUCTION = REGISTRY.register("conduction", () -> new ConductionEnchantment());
	public static final RegistryObject<Enchantment> SAVING_GRACE = REGISTRY.register("saving_grace", () -> new SavingGraceEnchantment());
	public static final RegistryObject<Enchantment> FROST = REGISTRY.register("frost", () -> new FrostEnchantment());
	public static final RegistryObject<Enchantment> AQUA_SLASH = REGISTRY.register("aqua_slash", () -> new AquaSlashEnchantment());
	public static final RegistryObject<Enchantment> HUNTER = REGISTRY.register("hunter", () -> new HunterEnchantment());
	public static final RegistryObject<Enchantment> SWIFTNESS = REGISTRY.register("swiftness", () -> new AccelerationEnchantment());
	public static final RegistryObject<Enchantment> SOUL_SPARK = REGISTRY.register("soul_spark", () -> new SoulSparkEnchantment());
	public static final RegistryObject<Enchantment> BOILING_CURSE = REGISTRY.register("boiling_curse", () -> new BoilingCurseEnchantment());
	public static final RegistryObject<Enchantment> FREEZING_CURSE = REGISTRY.register("freezing_curse", () -> new FreezingCurseEnchantment());
	public static final RegistryObject<Enchantment> BAD_DREAMS_CURSE = REGISTRY.register("bad_dreams_curse", () -> new BadDreamsCurseEnchantment());
	public static final RegistryObject<Enchantment> ANGELS_BLESSING = REGISTRY.register("angels_blessing", () -> new AngelsBlessingEnchantment());
	public static final RegistryObject<Enchantment> ROCK_MENDING = REGISTRY.register("rock_mending", () -> new RockMendingEnchantment());
	public static final RegistryObject<Enchantment> LEVITATING = REGISTRY.register("levitating", () -> new LevitatingEnchantment());
	public static final RegistryObject<Enchantment> DETONATION = REGISTRY.register("detonation", () -> new DetonationEnchantment());
	public static final RegistryObject<Enchantment> NIGHT_VISION = REGISTRY.register("night_vision", () -> new NightVisionEnchantment());
	public static final RegistryObject<Enchantment> AQUAPHOBIA_CURSE = REGISTRY.register("aquaphobia_curse", () -> new AquaphobiaCurseEnchantment());
	public static final RegistryObject<Enchantment> LEAPING = REGISTRY.register("leaping", () -> new LeapingEnchantment());
	public static final RegistryObject<Enchantment> DENSITY_CURSE = REGISTRY.register("density_curse", () -> new DensityCurseEnchantment());
	public static final RegistryObject<Enchantment> REACH = REGISTRY.register("reach", () -> new ReachEnchantment());
	public static final RegistryObject<Enchantment> BLOODTHIRST = REGISTRY.register("bloodthirst", () -> new BloodthirstEnchantment());
	public static final RegistryObject<Enchantment> REVENANT = REGISTRY.register("revenant", () -> new RevenantEnchantment());
	public static final RegistryObject<Enchantment> MAGMA_WALKER = REGISTRY.register("magma_walker", () -> new MagmaWalkerEnchantment());
	public static final RegistryObject<Enchantment> FIRE_COATING = REGISTRY.register("fire_coating", () -> new FireCoatingEnchantment());
	public static final RegistryObject<Enchantment> GROWTH = REGISTRY.register("growth", () -> new GrowthEnchantment());
}
